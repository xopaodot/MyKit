//
//  NEUserInfoModel.m
//  NetworkExtension
//
//  Created by daxiong on 2019/11/12.
//  Copyright © 2019 moonmd.xie. All rights reserved.
//

#import "NEUserInfoModel.h"

//balance = 9875;
//"ban_time" = 0;
//"created_at" = "2019-11-01 08:21:15";
//d = 865153653;
//enable = 1;
//"enable_time" = "2017-01-01";
//"expire_time" = "2099-01-01";
//gender = 1;
//id = 1;
//"is_admin" = 1;
//"last_login" = 1573024602;
//level = 1;
//method = "aes-256-cfb";
//obfs = plain;
//"obfs_param" = "";
//passwd = "@123";
//password = "$2y$10$ryMdx5ejvCSdjvZVZAPpOuxHrsAUY8FEINUATy6RCck6j9EeHhPfq";
//"pay_way" = 3;
//port = 10000;
//protocol = origin;
//"protocol_param" = "";
//qq = "";
//"referral_uid" = 0;
//"reg_ip" = "127.0.0.1";
//remark = "<null>";
//"remember_token" = HnQd3Cfkzx9z6lQNyaTz5AYlSug2hIRX53BAkZGJX9OdTAo998l93bJcW0if;
//"speed_limit_per_con" = 204800;
//"speed_limit_per_user" = 204800;
//status = 1;
//t = 1572950369;
//"traffic_reset_day" = 1;
//"transfer_enable" = 1315333734400;
//u = 1461377;
//"updated_at" = "2019-11-06 15:16:42";
//usage = 1;
//username = admin;
//"vmess_id" = "c6effafd-6046-7a84-376e-b0429751c304";
//wechat = "";

@implementation NEUserInfoModel





@end
