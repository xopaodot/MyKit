//
//  WDTabBarController.h
//  IOS-Weidai
//
//  Created by yaoqi on 16/5/13.
//  Copyright © 2016年 微贷（杭州）金融信息服务有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WDTabBarController : UITabBarController



@end
