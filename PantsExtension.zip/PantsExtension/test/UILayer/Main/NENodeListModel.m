//
//  NENodeListModel.m
//  NetworkExtension
//
//  Created by daxiong on 2019/11/13.
//  Copyright © 2019 moonmd.xie. All rights reserved.
//

#import "NENodeListModel.h"

@implementation NENodeListModel

@end
