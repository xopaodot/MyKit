//
//  WFMineTableViewCell.m
//  JiMei
//
//  Created by daxiong on 2019/4/12.
//  Copyright © 2019 大熊. All rights reserved.
//

#import "WFMineTableViewCell.h"

@implementation WFMineTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
