//
//  NEBannerModel.m
//  NetworkExtension
//
//  Created by daxiong on 2019/12/19.
//  Copyright © 2019 moonmd.xie. All rights reserved.
//

#import "NEBannerModel.h"

@implementation NEBannerModel

@end
