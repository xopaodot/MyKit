//
//  NERegisterViewController.h
//  NetworkExtension
//
//  Created by daxiong on 2019/11/7.
//  Copyright © 2019 moonmd.xie. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface NERegisterViewController : BaseViewController

@end

NS_ASSUME_NONNULL_END
