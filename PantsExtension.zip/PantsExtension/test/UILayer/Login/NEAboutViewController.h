//
//  NEAboutViewController.h
//  NetworkExtension
//
//  Created by daxiong on 2019/12/9.
//  Copyright © 2019 moonmd.xie. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface NEAboutViewController : BaseViewController

@end

NS_ASSUME_NONNULL_END
