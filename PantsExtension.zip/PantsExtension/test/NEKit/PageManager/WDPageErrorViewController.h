//
//  WDPageErrorViewController.h
//  WDPageManagerDemo
//
//  Created by dongmx on 15/4/23.
//  Copyright (c) 2015年 dongmx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WDPageErrorViewController : UIViewController

@end
