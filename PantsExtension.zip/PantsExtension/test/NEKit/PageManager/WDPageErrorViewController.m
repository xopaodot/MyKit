//
//  WDPageErrorViewController.m
//  WDPageManagerDemo
//
//  Created by dongmx on 15/4/23.
//  Copyright (c) 2015年 dongmx. All rights reserved.
//

#import "WDPageErrorViewController.h"

@interface WDPageErrorViewController ()

@end

@implementation WDPageErrorViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"错误";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
