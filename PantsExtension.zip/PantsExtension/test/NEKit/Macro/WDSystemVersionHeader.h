//
//  WDSystemVersionHeader.h
//  IOS-Weidai
//
//  Created by ai on 16/9/4.
//  Copyright © 2016年 微贷（杭州）金融信息服务有限公司. All rights reserved.
//

#ifndef WDSystemVersionHeader_h
#define WDSystemVersionHeader_h

#define IOS_8_Added [[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0

#endif /* WDSystemVersionHeader_h */
