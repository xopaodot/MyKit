//
//  WYJSONRequestSerializer.h
//  PalmHospital
//
//  Created by leon on 14-3-12.
//  Copyright (c) 2014年 lvxian. All rights reserved.
//

#import "AFURLRequestSerialization.h"

@interface WYJSONRequestSerializer : AFHTTPRequestSerializer

@end
