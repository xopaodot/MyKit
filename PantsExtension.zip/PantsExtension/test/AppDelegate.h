//
//  AppDelegate.h
//  test
//
//  Created by moonmd.xie on 2018/3/28.
//  Copyright © 2018年 moonmd.xie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

